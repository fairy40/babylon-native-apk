# Aetherium Nexus

Projeto de app nativo usando Babylon.js Native com NDK e CMake.